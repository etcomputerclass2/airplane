from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    pass
class auction_listings:
    title = models.CharField(max_length=32)
    description = models.CharField(max_length=250)
    price = models.IntegerField()
    catagory = models.CharField(max_length=25)
class bids:
    item_bid = models.CharField(max_length=64)
    amount = models.IntegerField()
    user = models.CharField(max_length=64)
class comment:
    item_commented_on  = models.CharField(max_length=640)
    text = models.CharField(max_length=250)
